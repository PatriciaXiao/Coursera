// true if white theme is used on website; false if black theme is used
var white = true;

/*
* the following function is called whenever the user clicks a button on the website to change the color theme
*/
function change_color() {
  white = !white; // switch from white to black theme and vice versa
  if (white) {
    // white blackground
    document.body.style.background = 'white';
    // back text in body
    document.getElementsByTagName('body')[0].style.color = 'black';
  } else {
    // black background
    document.body.style.background = 'black';
    // white text in body
    document.getElementsByTagName('body')[0].style.color = 'white';
  }
}
