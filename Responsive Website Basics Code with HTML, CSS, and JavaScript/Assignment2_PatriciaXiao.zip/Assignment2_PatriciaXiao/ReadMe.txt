Patricia Xiao wrote all these for a course assignment.
starting from index.html, a small project built on HTML, CSS and Javascript, introducing a bit of Patricia.
Thanks for watching & reading.
Have fun playing with it.